# Databricks notebook source
spark.sql("USE CATALOG supply_chain_ai")
spark.sql("USE SCHEMA silver")

# COMMAND ----------

temperature_df = spark.table("supply_chain_ai.bronze.temperature_raw")
humidity_df = spark.table("supply_chain_ai.bronze.humidity_raw")
pressure_df = spark.table("supply_chain_ai.bronze.pressure_raw")
wind_speed_df = spark.table("supply_chain_ai.bronze.wind_speed_raw")
wind_direction_df = spark.table("supply_chain_ai.bronze.wind_direction_raw")
weather_desc_df = spark.table("supply_chain_ai.bronze.weather_description_raw")

display(temperature_df)

# COMMAND ----------

from pyspark.sql.functions import expr

def unpivot_weather(df, value_name):
    
    cols = [c for c in df.columns if c != "datetime"]
    
    stack_expr = ", ".join([f"'{c}', `{c}`" for c in cols])
    
    unpivot_expr = f"stack({len(cols)}, {stack_expr}) as (city, {value_name})"
    
    return df.selectExpr("datetime", unpivot_expr)

# COMMAND ----------

temperature_long = unpivot_weather(temperature_df, "temperature")

display(temperature_long)

# COMMAND ----------

humidity_long = unpivot_weather(humidity_df, "humidity")

display(humidity_long)

# COMMAND ----------

pressure_long = unpivot_weather(pressure_df, "pressure")

display(pressure_long)

# COMMAND ----------

wind_speed_long = unpivot_weather(wind_speed_df, "wind_speed")

display(wind_speed_long)

# COMMAND ----------

wind_dir_long = unpivot_weather(wind_direction_df, "wind_direction")

display(wind_dir_long)

# COMMAND ----------

weather_desc_long = unpivot_weather(weather_desc_df, "weather_description")

display(weather_desc_long)

# COMMAND ----------

weather_combined = temperature_long \
.join(humidity_long, ["datetime", "city"]) \
.join(pressure_long, ["datetime", "city"]) \
.join(wind_speed_long, ["datetime", "city"]) \
.join(wind_dir_long, ["datetime", "city"]) \
.join(weather_desc_long, ["datetime", "city"])

display(weather_combined)

# COMMAND ----------

weather_clean = weather_combined.dropna()

weather_clean.count()

# COMMAND ----------

weather_clean.write \
.format("delta") \
.mode("overwrite") \
.saveAsTable("weather_clean")

# COMMAND ----------

spark.sql("SHOW TABLES").show()

# COMMAND ----------

spark.table("supply_chain_ai.silver.weather_clean").count()