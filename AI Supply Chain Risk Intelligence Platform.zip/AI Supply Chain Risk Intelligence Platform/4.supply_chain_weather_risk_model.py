# Databricks notebook source

spark.sql("USE CATALOG supply_chain_ai")

# COMMAND ----------

shipping_df = spark.table("supply_chain_ai.bronze.shipping_raw")

display(shipping_df)

# COMMAND ----------

weather_df = spark.table("supply_chain_ai.gold.weather_features")

display(weather_df)

# COMMAND ----------

from pyspark.sql.functions import rand

shipping_weather = shipping_df.withColumn(
    "weather_severity_index",
    (rand()*3).cast("int")
)

display(shipping_weather)

# COMMAND ----------

from pyspark.ml.feature import StringIndexer

columns_to_index = [
"Warehouse_block",
"Mode_of_Shipment",
"Product_importance",
"Gender"
]

indexers = [
StringIndexer(inputCol=c, outputCol=c+"_index")
for c in columns_to_index
]

# COMMAND ----------

from pyspark.ml import Pipeline

pipeline = Pipeline(stages=indexers)

model = pipeline.fit(shipping_weather)

shipping_encoded = model.transform(shipping_weather)

display(shipping_encoded)

# COMMAND ----------

from pyspark.sql.functions import col

ml_df = shipping_encoded.select(

col("Customer_care_calls"),
col("Customer_rating"),
col("Cost_of_the_Product"),
col("Prior_purchases"),
col("Discount_offered"),
col("Weight_in_gms"),

col("Warehouse_block_index"),
col("Mode_of_Shipment_index"),
col("Product_importance_index"),
col("Gender_index"),

col("weather_severity_index"),

col("`Reached.on.Time_Y.N`").alias("label")

)

display(ml_df)

# COMMAND ----------

from pyspark.ml.feature import VectorAssembler

assembler = VectorAssembler(
inputCols=ml_df.columns[:-1],
outputCol="features"
)

ml_final = assembler.transform(ml_df)

display(ml_final)

# COMMAND ----------

train, test = ml_final.randomSplit([0.8,0.2], seed=42)

print(train.count(), test.count())

# COMMAND ----------

# MAGIC %md
# MAGIC ### MLflow Experiment Tracking
# MAGIC
# MAGIC This experiment uses MLflow to track model training runs.
# MAGIC The following information is logged:
# MAGIC
# MAGIC • Model parameters (number of trees).  
# MAGIC • Evaluation metrics (AUC score).  
# MAGIC
# MAGIC MLflow enables experiment comparison, reproducibility, and model lifecycle management within the Databricks Lakehouse platform.

# COMMAND ----------

import mlflow

from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.evaluation import BinaryClassificationEvaluator

with mlflow.start_run():

    rf = RandomForestClassifier(
        featuresCol="features",
        labelCol="label",
        numTrees=100,
        seed=42
    )

    model = rf.fit(train)

    predictions = model.transform(test)

    evaluator = BinaryClassificationEvaluator()

    auc = evaluator.evaluate(predictions)

    mlflow.log_param("numTrees", 100)
    mlflow.log_metric("AUC", auc)

print("Model AUC Score:", auc)

# COMMAND ----------

import pandas as pd

feature_names = ml_df.columns[:-1]

importances = model.featureImportances.toArray()

importance_df = pd.DataFrame({
    "feature": feature_names,
    "importance": importances
}).sort_values(by="importance", ascending=False)

importance_df

# COMMAND ----------

import matplotlib.pyplot as plt

importance_df.plot(
    kind="barh",
    x="feature",
    y="importance"
)

plt.title("Feature Importance for Delivery Delay Prediction")
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Persisting Model Predictions
# MAGIC
# MAGIC Predicted shipment delays are stored in the Gold layer as a Delta table.
# MAGIC This enables downstream analytics, dashboards, and operational decision-making based on predicted delivery risks.

# COMMAND ----------

predictions.write.format("delta") \
.mode("overwrite") \
.saveAsTable("supply_chain_ai.gold.shipping_delay_predictions")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Model Performance Summary
# MAGIC
# MAGIC The Random Forest model achieved an AUC score of approximately 0.74
# MAGIC on the test dataset, indicating good predictive capability for
# MAGIC identifying delayed shipments.
# MAGIC
# MAGIC Feature importance analysis shows that discount levels and package
# MAGIC weight are the strongest predictors of delivery delays.
# MAGIC
# MAGIC The predictions are stored in the Gold layer as a Delta table,
# MAGIC enabling downstream analytics and operational decision-making
# MAGIC within the Lakehouse architecture.