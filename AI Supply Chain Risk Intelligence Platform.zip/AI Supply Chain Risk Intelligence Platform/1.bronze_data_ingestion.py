# Databricks notebook source
spark.sql("USE CATALOG supply_chain_ai")
spark.sql("USE SCHEMA bronze")

# COMMAND ----------

display(dbutils.fs.ls("/Volumes/supply_chain_ai/bronze/raw_data/"))

# COMMAND ----------

shipping_df = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load("/Volumes/supply_chain_ai/bronze/raw_data/Train.csv")
)

display(shipping_df)

# COMMAND ----------

shipping_df.write.format("delta") \
.mode("overwrite") \
.saveAsTable("shipping_raw")

# COMMAND ----------

def clean_columns(df):
    for col in df.columns:
        df = df.withColumnRenamed(col, col.replace(" ", "_"))
    return df

# COMMAND ----------

temperature_df = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load("/Volumes/supply_chain_ai/bronze/raw_data/temperature.csv")
)

temperature_df = clean_columns(temperature_df)

display(temperature_df)

# COMMAND ----------

temperature_df.write.format("delta") \
.mode("overwrite") \
.saveAsTable("temperature_raw")

# COMMAND ----------

humidity_df = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load("/Volumes/supply_chain_ai/bronze/raw_data/humidity.csv")
)

humidity_df = clean_columns(humidity_df)

display(humidity_df)

# COMMAND ----------

humidity_df.write.format("delta") \
.mode("overwrite") \
.saveAsTable("humidity_raw")

# COMMAND ----------

pressure_df = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load("/Volumes/supply_chain_ai/bronze/raw_data/pressure.csv")
)

pressure_df = clean_columns(pressure_df)

display(pressure_df)

# COMMAND ----------

pressure_df.write.format("delta") \
.mode("overwrite") \
.saveAsTable("pressure_raw")

# COMMAND ----------

wind_speed_df = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load("/Volumes/supply_chain_ai/bronze/raw_data/wind_speed.csv")
)

wind_speed_df = clean_columns(wind_speed_df)

display(wind_speed_df)

# COMMAND ----------

wind_speed_df.write.format("delta") \
.mode("overwrite") \
.saveAsTable("wind_speed_raw")

# COMMAND ----------

wind_direction_df = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load("/Volumes/supply_chain_ai/bronze/raw_data/wind_direction.csv")
)

wind_direction_df = clean_columns(wind_direction_df)

display(wind_direction_df)

# COMMAND ----------

wind_direction_df.write.format("delta") \
.mode("overwrite") \
.saveAsTable("wind_direction_raw")

# COMMAND ----------

weather_description_df = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load("/Volumes/supply_chain_ai/bronze/raw_data/weather_description.csv")
)

weather_description_df = clean_columns(weather_description_df)

display(weather_description_df)

# COMMAND ----------

weather_description_df.write.format("delta") \
.mode("overwrite") \
.saveAsTable("weather_description_raw")

# COMMAND ----------

city_df = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load("/Volumes/supply_chain_ai/bronze/raw_data/city_attributes.csv")
)

city_df = clean_columns(city_df)

display(city_df)

# COMMAND ----------

city_df.write.format("delta") \
.mode("overwrite") \
.saveAsTable("city_attributes_raw")

# COMMAND ----------

spark.sql("SHOW TABLES IN supply_chain_ai.bronze").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Governance
# MAGIC
# MAGIC The project uses Unity Catalog for centralized data governance.
# MAGIC
# MAGIC Benefits include:
# MAGIC
# MAGIC • Controlled access to datasets.  
# MAGIC • Consistent data discovery across teams.  
# MAGIC • Secure sharing of analytics tables.  
# MAGIC • Metadata management for lineage tracking.  