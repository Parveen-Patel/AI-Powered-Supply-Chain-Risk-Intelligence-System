# Databricks notebook source
# Set catalog and schema
spark.sql("USE CATALOG supply_chain_ai")
spark.sql("USE SCHEMA silver")

# COMMAND ----------

weather_df = spark.table("supply_chain_ai.silver.weather_clean")

display(weather_df)

# COMMAND ----------

from pyspark.sql.functions import hour, dayofweek, month

weather_features = weather_df \
.withColumn("hour", hour("datetime")) \
.withColumn("day_of_week", dayofweek("datetime")) \
.withColumn("month", month("datetime"))

display(weather_features)

# COMMAND ----------

from pyspark.sql.functions import when

weather_features = weather_features.withColumn(
    "extreme_temperature_flag",
    when((weather_features.temperature < 273) | (weather_features.temperature > 310), 1).otherwise(0)
)

display(weather_features)

# COMMAND ----------

weather_features = weather_features.withColumn(
    "wind_risk_index",
    when(weather_features.wind_speed > 15, 2)
    .when(weather_features.wind_speed > 8, 1)
    .otherwise(0)
)

display(weather_features)

# COMMAND ----------

weather_features = weather_features.withColumn(
    "pressure_drop_flag",
    when(weather_features.pressure < 1000, 1).otherwise(0)
)

display(weather_features)

# COMMAND ----------

from pyspark.sql.functions import col

weather_features = weather_features.withColumn(
    "weather_severity_index",
    col("extreme_temperature_flag") +
    col("wind_risk_index") +
    col("pressure_drop_flag")
)

display(weather_features)

# COMMAND ----------

weather_features.select(
    "city",
    "datetime",
    "temperature",
    "wind_speed",
    "pressure",
    "weather_severity_index"
).show(20)

# COMMAND ----------

spark.sql("USE SCHEMA gold")
weather_features.write \
.format("delta") \
.mode("overwrite") \
.saveAsTable("supply_chain_ai.gold.weather_features")

# COMMAND ----------

spark.sql("SHOW TABLES").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Delta Lake ACID Transactions
# MAGIC
# MAGIC The dataset is stored using Delta tables in the Databricks Lakehouse.
# MAGIC
# MAGIC Delta Lake provides built-in ACID transaction guarantees:
# MAGIC
# MAGIC • Atomicity – operations either fully succeed or fail.  
# MAGIC • Consistency – data remains valid after each transaction.  
# MAGIC • Isolation – concurrent operations do not corrupt data.  
# MAGIC • Durability – committed data is permanently stored.  
# MAGIC
# MAGIC The following query shows the transaction history of the table,
# MAGIC demonstrating Delta Lake version control and auditability.

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY supply_chain_ai.bronze.shipping_raw

# COMMAND ----------

# MAGIC %md
# MAGIC ### Delta Lake Time Travel
# MAGIC
# MAGIC Delta Lake allows querying previous versions of a table.
# MAGIC
# MAGIC This capability enables:
# MAGIC
# MAGIC • Data reproducibility.  
# MAGIC • Debugging pipelines.  
# MAGIC • Restoring previous states of data.  

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM supply_chain_ai.bronze.shipping_raw
# MAGIC VERSION AS OF 0
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table Optimization
# MAGIC
# MAGIC Delta tables can be optimized to improve query performance.
# MAGIC
# MAGIC OPTIMIZE compacts small files into larger ones, while ZORDER
# MAGIC clusters related data together to improve data skipping and
# MAGIC query efficiency.

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE supply_chain_ai.gold.weather_features ZORDER BY (weather_severity_index)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Scalability Considerations
# MAGIC
# MAGIC This pipeline is designed for large-scale logistics datasets.
# MAGIC
# MAGIC Key scalability strategies:
# MAGIC
# MAGIC • Distributed processing using Apache Spark.  
# MAGIC • Delta Lake storage format for optimized reads and writes.  
# MAGIC • Columnar storage for efficient analytical queries.  
# MAGIC • Aggregation performed using Spark SQL for parallel execution.      
# MAGIC • Pipeline architecture supports scaling to millions of shipments.    
# MAGIC
# MAGIC This design ensures the system can handle enterprise-scale logistics data.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Cost Optimization Strategies
# MAGIC
# MAGIC The pipeline incorporates several techniques to minimize
# MAGIC compute and storage costs:
# MAGIC
# MAGIC • Delta Lake columnar storage reduces storage overhead.  
# MAGIC • Table optimization improves query performance.  
# MAGIC • Z-Ordering accelerates filtering queries.  
# MAGIC • Efficient Spark transformations minimize compute usage.  
# MAGIC • Scheduled batch jobs avoid unnecessary cluster runtime.  
# MAGIC
# MAGIC These practices ensure efficient use of cloud resources.